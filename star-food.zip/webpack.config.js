module.exports = {
    entry: './src/js/main.js',
    output: {
        path: 'src',
        filename: 'bundle.js'
    }
};
